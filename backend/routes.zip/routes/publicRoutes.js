const express = require("express");
const publicController = require("../controllers/publicController");
const router = express.Router();
router.get("/stats", publicController.transparencyStats);
router.get("/settings", publicController.publicSettings);
router.get("/july-sathi", publicController.julySathiActions);
module.exports = router;
