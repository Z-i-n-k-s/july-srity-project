const express = require("express");
const auth = require("../controllers/authController");
const { authenticate } = require("../middleware/auth");
const { authLimiter } = require("../middleware/rateLimits");

const router = express.Router();
router.post("/signup", authLimiter, auth.signUp);
router.post("/signin", authLimiter, auth.signIn);
router.post("/refresh", authLimiter, auth.refresh);
router.post("/logout", auth.logout);
router.post("/logout-all", authenticate, auth.logoutAll);
router.post("/forgot-password", authLimiter, auth.forgotPassword);
router.get("/verify-reset-token/:token", authLimiter, auth.verifyResetToken);
router.post("/reset-password", authLimiter, auth.resetPassword);

module.exports = router;
