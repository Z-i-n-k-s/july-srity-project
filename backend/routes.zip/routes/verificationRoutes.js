const express = require("express");
const verification = require("../controllers/verificationController");
const { authenticate } = require("../middleware/auth");
const authorize = require("../middleware/authorize");
const validateObjectId = require("../middleware/validateObjectId");

const router = express.Router();
router.get("/public/:targetType/:targetId", validateObjectId("targetId"), verification.getPublicForTarget);
router.use(authenticate, authorize("ADMIN"));
router.post("/", verification.create);
router.get("/", verification.list);
router.get("/:reviewId", validateObjectId("reviewId"), verification.getById);
router.patch("/:reviewId", validateObjectId("reviewId"), verification.update);
router.post("/:reviewId/finalize", validateObjectId("reviewId"), verification.finalize);
module.exports = router;
