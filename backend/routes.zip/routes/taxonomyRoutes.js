const express = require("express");
const tags = require("../controllers/tagController");
const locations = require("../controllers/locationController");
const { authenticate } = require("../middleware/auth");
const authorize = require("../middleware/authorize");
const validateObjectId = require("../middleware/validateObjectId");

const router = express.Router();
router.get("/tags", tags.list);
router.get("/tags/:id", validateObjectId("id"), tags.getById);
router.post("/tags", authenticate, authorize("ADMIN"), tags.create);
router.patch("/tags/:id", authenticate, authorize("ADMIN"), validateObjectId("id"), tags.update);
router.delete("/tags/:id", authenticate, authorize("ADMIN"), validateObjectId("id"), tags.remove);

router.get("/locations/nearby", locations.nearby);
router.get("/locations", locations.list);
router.get("/locations/:id", validateObjectId("id"), locations.getById);
router.post("/locations", authenticate, authorize("ADMIN"), locations.create);
router.patch("/locations/:id", authenticate, authorize("ADMIN"), validateObjectId("id"), locations.update);
router.delete("/locations/:id", authenticate, authorize("ADMIN"), validateObjectId("id"), locations.remove);
module.exports = router;
