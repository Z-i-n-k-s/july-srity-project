const express = require("express");
const missing = require("../controllers/missingPersonController");
const { authenticate, optionalAuthenticate } = require("../middleware/auth");
const authorize = require("../middleware/authorize");
const validateObjectId = require("../middleware/validateObjectId");

const router = express.Router();
router.get("/", missing.listPublic);
router.get("/public/:reportId", validateObjectId("reportId"), missing.getPublic);
router.post("/:reportId/sightings", optionalAuthenticate, validateObjectId("reportId"), missing.createSighting);

router.use(authenticate);
router.post("/", missing.create);
router.get("/mine", missing.listMine);
router.get("/admin", authorize("ADMIN"), missing.listAdmin);
router.get("/:reportId", validateObjectId("reportId"), missing.getPrivate);
router.patch("/:reportId", validateObjectId("reportId"), missing.update);
router.post("/:reportId/submit", validateObjectId("reportId"), missing.submitForReview);
router.patch("/:reportId/assign", authorize("ADMIN"), validateObjectId("reportId"), missing.assignAdmins);
router.patch("/:reportId/status", authorize("ADMIN"), validateObjectId("reportId"), missing.changeStatus);
router.patch("/:reportId/sightings/:sightingId/status", authorize("ADMIN"), validateObjectId("reportId", "sightingId"), missing.changeSightingStatus);
router.delete("/:reportId", validateObjectId("reportId"), missing.remove);
module.exports = router;
