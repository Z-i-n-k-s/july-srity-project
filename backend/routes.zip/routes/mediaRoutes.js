const express = require("express");
const media = require("../controllers/mediaController");
const upload = require("../middleware/upload");
const { authenticate } = require("../middleware/auth");
const authorize = require("../middleware/authorize");
const validateObjectId = require("../middleware/validateObjectId");

const router = express.Router();
router.use(authenticate);
router.post("/", upload.single("file"), media.uploadMedia);
router.get("/mine", media.listMyMedia);
router.get("/admin", authorize("ADMIN"), media.listAllMedia);
router.get("/:mediaId", validateObjectId("mediaId"), media.getMedia);
router.patch("/:mediaId", validateObjectId("mediaId"), media.updateMedia);
router.delete("/:mediaId", validateObjectId("mediaId"), media.deleteMedia);
module.exports = router;
