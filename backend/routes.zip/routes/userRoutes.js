const express = require("express");
const users = require("../controllers/userController");
const { authenticate } = require("../middleware/auth");
const authorize = require("../middleware/authorize");
const validateObjectId = require("../middleware/validateObjectId");

const router = express.Router();
router.use(authenticate);
router.get("/me", users.getMe);
router.patch("/me", users.updateMe);
router.delete("/me", users.deleteMe);
router.get("/", authorize("ADMIN"), users.listUsers);
router.get("/:userId", authorize("ADMIN"), validateObjectId("userId"), users.getUser);
router.patch("/:userId", authorize("ADMIN"), validateObjectId("userId"), users.updateUser);
router.delete("/:userId", authorize("ADMIN"), validateObjectId("userId"), users.deleteUser);
module.exports = router;
