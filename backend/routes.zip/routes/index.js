const express = require("express");
const authRoutes = require("./authRoutes");
const userRoutes = require("./userRoutes");
const mediaRoutes = require("./mediaRoutes");
const taxonomyRoutes = require("./taxonomyRoutes");
const archiveRoutes = require("./archiveRoutes");
const submissionRoutes = require("./submissionRoutes");
const verificationRoutes = require("./verificationRoutes");
const supportRoutes = require("./supportRoutes");
const missingPersonRoutes = require("./missingPersonRoutes");
const conversationRoutes = require("./conversationRoutes");
const notificationRoutes = require("./notificationRoutes");
const governanceRoutes = require("./governanceRoutes");
const publicRoutes = require("./publicRoutes");
const offlineRoutes = require("./offlineRoutes");
const auth = require("../controllers/authController");
const users = require("../controllers/userController");
const legacy = require("../controllers/legacyController");
const { authenticate } = require("../middleware/auth");
const authorize = require("../middleware/authorize");
const { authLimiter } = require("../middleware/rateLimits");
const AppError = require("../helpers/AppError");

const router = express.Router();

router.use("/auth", authRoutes);
router.use("/users", userRoutes);
router.use("/media", mediaRoutes);
router.use("/taxonomy", taxonomyRoutes);
router.use("/archive", archiveRoutes);
router.use("/submissions", submissionRoutes);
router.use("/verifications", verificationRoutes);
router.use("/support-cases", supportRoutes);
router.use("/missing-persons", missingPersonRoutes);
router.use("/conversations", conversationRoutes);
router.use("/notifications", notificationRoutes);
router.use("/governance", governanceRoutes);
router.use("/public", publicRoutes);
router.use("/offline", offlineRoutes);
router.use("/", taxonomyRoutes);

// Backward-compatible aliases for the existing frontend.
router.post("/signup", authLimiter, auth.signUp);
router.post("/signin", authLimiter, auth.signIn);
router.get("/user-details", authenticate, users.getMe);
router.get("/userLogout", auth.logout);
router.post("/userLogout", auth.logout);
router.post("/forgot-password", authLimiter, auth.forgotPassword);
router.post("/reset-password", authLimiter, auth.resetPassword);
router.get("/verify-reset-token/:token", authLimiter, auth.verifyResetToken);
router.get("/all-user", authenticate, authorize("ADMIN"), users.listUsers);
router.post("/user-search", authenticate, authorize("ADMIN"), legacy.searchUserByEmail);
router.post("/update-profile", authenticate, users.updateMe);
router.post(
  "/update-user",
  authenticate,
  authorize("ADMIN"),
  (req, _res, next) => {
    if (!req.body.userId) return next(new AppError("userId is required.", 422, "USER_ID_REQUIRED"));
    req.params.userId = req.body.userId;
    next();
  },
  users.updateUser
);
router.post(
  "/delete-user",
  authenticate,
  authorize("ADMIN"),
  (req, _res, next) => {
    if (!req.body.userId) return next(new AppError("userId is required.", 422, "USER_ID_REQUIRED"));
    req.params.userId = req.body.userId;
    next();
  },
  users.deleteUser
);

module.exports = router;
