const express = require("express");
const notifications = require("../controllers/notificationController");
const { authenticate } = require("../middleware/auth");
const validateObjectId = require("../middleware/validateObjectId");

const router = express.Router();
router.use(authenticate);
router.get("/", notifications.list);
router.patch("/read-all", notifications.markAllRead);
router.patch("/:notificationId/read", validateObjectId("notificationId"), notifications.markRead);
router.delete("/:notificationId", validateObjectId("notificationId"), notifications.remove);
module.exports = router;
