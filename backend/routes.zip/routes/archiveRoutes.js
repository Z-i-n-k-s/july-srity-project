const express = require("express");
const events = require("../controllers/julyEventController");
const items = require("../controllers/documentaryItemController");
const { authenticate } = require("../middleware/auth");
const authorize = require("../middleware/authorize");
const validateObjectId = require("../middleware/validateObjectId");

const router = express.Router();
router.get("/events", events.listPublic);
router.get("/events/slug/:slug", events.getPublicBySlug);
router.get("/items", items.listPublic);
router.get("/items/slug/:slug", items.getPublicBySlug);

router.use(authenticate, authorize("ADMIN"));
router.get("/admin/events", events.listAdmin);
router.post("/admin/events", events.create);
router.get("/admin/events/:eventId", validateObjectId("eventId"), events.getAdmin);
router.patch("/admin/events/:eventId", validateObjectId("eventId"), events.update);
router.patch("/admin/events/:eventId/status", validateObjectId("eventId"), events.changeStatus);
router.delete("/admin/events/:eventId", validateObjectId("eventId"), events.remove);

router.get("/admin/items", items.listAdmin);
router.post("/admin/items", items.create);
router.post("/admin/items/from-submission/:submissionId", validateObjectId("submissionId"), items.createFromSubmission);
router.post("/admin/items/apply-correction/:submissionId", validateObjectId("submissionId"), items.applyCorrection);
router.get("/admin/items/:itemId", validateObjectId("itemId"), items.getAdmin);
router.patch("/admin/items/:itemId", validateObjectId("itemId"), items.update);
router.patch("/admin/items/:itemId/status", validateObjectId("itemId"), items.changeStatus);
router.get("/admin/items/:itemId/versions", validateObjectId("itemId"), items.listVersions);
router.delete("/admin/items/:itemId", validateObjectId("itemId"), items.remove);
module.exports = router;
