const express = require("express");
const submissions = require("../controllers/documentarySubmissionController");
const support = require("../controllers/supportController");
const { authenticate } = require("../middleware/auth");

const router = express.Router();
router.use(authenticate);

// The frontend should sync one queued draft at a time and keep clientDraftId stable across retries.
router.post("/sync/testimony", submissions.create);
router.post("/sync/support-request", support.create);

module.exports = router;
