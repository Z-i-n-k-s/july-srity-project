const express = require("express");
const consent = require("../controllers/consentController");
const moderation = require("../controllers/moderationController");
const admin = require("../controllers/adminController");
const { authenticate } = require("../middleware/auth");
const authorize = require("../middleware/authorize");
const validateObjectId = require("../middleware/validateObjectId");

const router = express.Router();
router.use(authenticate);
router.get("/consents/mine", consent.listMine);
router.post("/consents", consent.grant);
router.post("/consents/:consentId/withdraw", validateObjectId("consentId"), consent.withdraw);
router.post("/moderation-reports", moderation.create);
router.get("/moderation-reports/mine", moderation.listMine);
router.get("/moderation-reports/admin", authorize("ADMIN"), moderation.listAdmin);
router.patch("/moderation-reports/:reportId/status", authorize("ADMIN"), validateObjectId("reportId"), moderation.updateStatus);

router.get("/admin/notes", authorize("ADMIN"), admin.listNotes);
router.post("/admin/notes", authorize("ADMIN"), admin.createNote);
router.patch("/admin/notes/:noteId", authorize("ADMIN"), validateObjectId("noteId"), admin.updateNote);
router.delete("/admin/notes/:noteId", authorize("ADMIN"), validateObjectId("noteId"), admin.deleteNote);
router.get("/admin/audit-logs", authorize("ADMIN"), admin.listAuditLogs);
router.get("/admin/settings", authorize("ADMIN"), admin.listSettings);
router.get("/admin/settings/:key", authorize("ADMIN"), admin.getSetting);
router.put("/admin/settings/:key", authorize("ADMIN"), admin.upsertSetting);
router.delete("/admin/settings/:key", authorize("ADMIN"), admin.deleteSetting);
module.exports = router;
