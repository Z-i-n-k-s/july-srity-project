const express = require("express");
const submissions = require("../controllers/documentarySubmissionController");
const { authenticate } = require("../middleware/auth");
const authorize = require("../middleware/authorize");
const validateObjectId = require("../middleware/validateObjectId");

const router = express.Router();
router.use(authenticate);
router.post("/", submissions.create);
router.get("/mine", submissions.listMine);
router.get("/admin", authorize("ADMIN"), submissions.listAdmin);
router.get("/:submissionId", validateObjectId("submissionId"), submissions.getById);
router.patch("/:submissionId", validateObjectId("submissionId"), submissions.update);
router.post("/:submissionId/submit", validateObjectId("submissionId"), submissions.submitForReview);
router.patch("/:submissionId/assign", authorize("ADMIN"), validateObjectId("submissionId"), submissions.assignAdmin);
router.patch("/:submissionId/status", authorize("ADMIN"), validateObjectId("submissionId"), submissions.changeStatus);
router.delete("/:submissionId", validateObjectId("submissionId"), submissions.remove);
module.exports = router;
